<?php
return array(
	//'配置项'=>'配置值'
		//'配置项'=>'配置值'
		'DB_TYPE'               =>  'mysql',     // 数据库类型
		'DB_HOST'               =>  'bdm247650322.my3w.com', // 服务器地址
		'DB_NAME'               =>  'bdm247650322_db',          // 数据库名
		'DB_USER'               =>  'bdm247650322',      // 用户名
		'DB_PWD'                =>  '528478huaHUA',          // 密码
		
);