<?php
namespace Admin\Model;
use Think\Model;
class Rpj_prod_paramModel extends Model
{
    public function Rpj_prod_param()
    {

    }
}
