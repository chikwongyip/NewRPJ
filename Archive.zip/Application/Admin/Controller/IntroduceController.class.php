<?php
namespace Admin\Controller;
use Think\Controller;
class IntroduceController extends Controller
{
    public function introduce()
    {
        $this->display();
    }
}
