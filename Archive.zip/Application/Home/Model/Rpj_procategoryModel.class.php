<?php
namespace Admin\Model;
use Think\Model;
class Rpj_procategoryModel extends Model
{
    public function Rpj_procategory()
    {

    }
}
