<?php
namespace Admin\Model;
use Think\Model;
class Rpj_Company extends Model
{
    public function rpj_company()
    {

    }
}
