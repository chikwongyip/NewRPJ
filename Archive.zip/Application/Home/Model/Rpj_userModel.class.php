<?php
namespace Admin\Model;
use Think\Model;
class Rpj_userModel extends Model
{
    public function rpj_user()
    {

    }
}
