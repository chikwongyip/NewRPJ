<?php
namespace Admin\Model;
use Think\Model;
class Rpj_product_pic extends Model
{
    public function Rpj_product_pic()
    {

    }
}