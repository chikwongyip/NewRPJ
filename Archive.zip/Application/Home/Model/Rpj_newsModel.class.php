<?php
namespace Admin\Model;
use Think\Model;
class Rpj_newsModel extends Model
{
    public function rpj_news()
    {

    }
}
