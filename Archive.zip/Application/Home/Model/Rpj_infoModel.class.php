<?php
namespace Admin\Model;
use Think\Model;
class Rpj_infoModel extends Model
{
    public function rpj_info()
    {

    }
}
