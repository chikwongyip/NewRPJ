<?php
namespace Admin\Model;
use Think\Model;
class Rpj_attachementModel extends Model
{
    public function rpj_attachement()
    {

    }
}
