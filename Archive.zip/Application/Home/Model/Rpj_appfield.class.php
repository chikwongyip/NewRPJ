<?php
namespace Admin\Model;
use Think\Model;
class Rpj_appfieldModel extends Model
{
    public function rpj_appfield()
    {

    }
}
