<?php
namespace Admin\Model;
use Think\Model;
class Rpj_productModel extends Model
{
    public function rpj_product()
    {

    }
}
