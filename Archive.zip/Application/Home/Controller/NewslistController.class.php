<?php
namespace Home\Controller;
use Think\Controller;
class NewslistController extends Controller
{
    public  function newslist(){
        $this->display();
    }
}
